package com.staffchat.player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_3222;

/**
 * Manages player-specific state like chat mode preference
 */
public class PlayerStateManager {
    private static final Map<UUID, PlayerChatMode> playerChatModes = new HashMap<>();

    public enum PlayerChatMode {
        NORMAL("normal"),
        STAFF("staff");

        private final String displayName;

        PlayerChatMode(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    /**
     * Get a player's current chat mode
     */
    public static PlayerChatMode getChatMode(class_3222 player) {
        return playerChatModes.getOrDefault(player.method_5667(), PlayerChatMode.NORMAL);
    }

    /**
     * Get a player's current chat mode by UUID
     */
    public static PlayerChatMode getChatMode(UUID playerUUID) {
        return playerChatModes.getOrDefault(playerUUID, PlayerChatMode.NORMAL);
    }

    /**
     * Set a player's chat mode
     */
    public static void setChatMode(class_3222 player, PlayerChatMode mode) {
        playerChatModes.put(player.method_5667(), mode);
    }

    /**
     * Set a player's chat mode by UUID
     */
    public static void setChatMode(UUID playerUUID, PlayerChatMode mode) {
        playerChatModes.put(playerUUID, mode);
    }

    /**
     * Remove a player's chat mode (when they disconnect)
     */
    public static void removePlayer(class_3222 player) {
        playerChatModes.remove(player.method_5667());
    }

    /**
     * Remove a player's chat mode by UUID
     */
    public static void removePlayer(UUID playerUUID) {
        playerChatModes.remove(playerUUID);
    }
}
