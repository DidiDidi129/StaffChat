package com.staffchat.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.staffchat.config.StaffChatConfig;
import com.staffchat.discord.DiscordWebhookHandler;
import com.staffchat.permission.PermissionChecker;
import com.staffchat.player.PlayerStateManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Command registration for StaffChat
 */
public class StaffChatCommands {

    /**
     * Register staff chat commands
     */
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            // Register /staffchat command with subcommands
            dispatcher.register(
                    method_9247("staffchat")
                            .then(method_9244("message", StringArgumentType.greedyString())
                                    .executes(context -> handleStaffChat(context.getSource(), StringArgumentType.getString(context, "message"))))
                            .then(method_9247("reload")
                                    .executes(context -> handleReload(context.getSource())))
            );

            // Register /sc alias
            dispatcher.register(
                    method_9247("sc")
                            .then(method_9244("message", StringArgumentType.greedyString())
                                    .executes(context -> handleStaffChat(context.getSource(), StringArgumentType.getString(context, "message"))))
            );

            // Register /chat command with subcommands
            dispatcher.register(
                    method_9247("chat")
                            .then(method_9247("normal")
                                    .executes(context -> handleChatMode(context.getSource(), PlayerStateManager.PlayerChatMode.NORMAL)))
                            .then(method_9247("staff")
                                    .executes(context -> handleChatMode(context.getSource(), PlayerStateManager.PlayerChatMode.STAFF)))
            );
        });
    }

    /**
     * Handle staff chat command execution
     */
    private static int handleStaffChat(class_2168 source, String message) {
        // Get the server
        var server = source.method_9211();
        if (server == null) {
            source.method_9213(class_2561.method_43470("Server not found"));
            return 0;
        }

        if (!source.method_43737()) {
            String formattedMessage = "§9[Staff] §r§c[Console]§r " + message;

            server.method_3760().method_14571().forEach(p -> {
                if (PermissionChecker.hasPermission(p, StaffChatConfig.getPermissionNode())) {
                    p.method_7353(class_2561.method_43470(formattedMessage), false);
                }
            });

            DiscordWebhookHandler.sendMessage("Console", message);
            return Command.SINGLE_SUCCESS;
        }

        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }

        // Check permission
        if (!PermissionChecker.hasPermission(player, StaffChatConfig.getPermissionNode())) {
            source.method_9213(class_2561.method_43470("§cYou do not have permission to use staff chat"));
            return 0;
        }

        // Format and send the message
        String formattedMessage = formatMessage(player.method_5477().getString(), message);

        // Send message to all players with permission
        server.method_3760().method_14571().forEach(p -> {
            if (PermissionChecker.hasPermission(p, StaffChatConfig.getPermissionNode())) {
                p.method_7353(class_2561.method_43470(formattedMessage), false);
            }
        });

        // Send to Discord webhook if enabled
        DiscordWebhookHandler.sendMessage(player.method_5477().getString(), message);

        return Command.SINGLE_SUCCESS;
    }

    /**
     * Handle reload command
     */
    private static int handleReload(class_2168 source) {
        // Check if the source is from a player
        if (!source.method_43737()) {
            source.method_9213(class_2561.method_43470("This command can only be executed by players"));
            return 0;
        }

        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }

        // Check permission (require staff chat permission to reload config)
        if (!PermissionChecker.hasPermission(player, StaffChatConfig.getPermissionNode())) {
            source.method_9213(class_2561.method_43470("§cYou do not have permission to reload the config"));
            return 0;
        }

        try {
            StaffChatConfig.loadConfig();
            player.method_7353(class_2561.method_43470("§a[Staff] Config reloaded successfully!"), false);

            // Notify all staff about the reload
            var server = source.method_9211();
            if (server != null) {
                server.method_3760().method_14571().forEach(p -> {
                    if (PermissionChecker.hasPermission(p, StaffChatConfig.getPermissionNode())) {
                        p.method_7353(class_2561.method_43470("§9[Staff] §rConfig was reloaded by " + player.method_5477().getString()), false);
                    }
                });
            }

            return Command.SINGLE_SUCCESS;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("§cFailed to reload config: " + e.getMessage()));
            return 0;
        }
    }

    /**
     * Handle chat mode switching
     */
    private static int handleChatMode(class_2168 source, PlayerStateManager.PlayerChatMode mode) {
        // Check if the source is from a player
        if (!source.method_43737()) {
            source.method_9213(class_2561.method_43470("This command can only be executed by players"));
            return 0;
        }

        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("Player not found"));
            return 0;
        }

        // Set the player's chat mode
        PlayerStateManager.setChatMode(player, mode);

        if (mode == PlayerStateManager.PlayerChatMode.STAFF) {
            // Check if player has staff chat permission first
            if (!PermissionChecker.hasPermission(player, StaffChatConfig.getPermissionNode())) {
                PlayerStateManager.setChatMode(player, PlayerStateManager.PlayerChatMode.NORMAL);
                source.method_9213(class_2561.method_43470("§cYou do not have permission to use staff chat"));
                return 0;
            }
            player.method_7353(class_2561.method_43470("§9§lYou are now speaking in Staff chat. §r§9To switch back to normal, do §l/chat normal"), false);
        } else {
            player.method_7353(class_2561.method_43470("§b§lYou are now speaking in Normal chat. §r§bTo switch to staff chat, do §l/chat staff"), false);
        }

        return Command.SINGLE_SUCCESS;
    }

    /**
     * Format staff chat message
     */
    private static String formatMessage(String playerName, String message) {
        // Convert & color codes to § codes
        String prefix = StaffChatConfig.getMessagePrefix().replace("&", "§");
        return prefix + playerName + ": " + message;
    }
}
